.. default-domain:: py
.. currentmodule:: natsort

:func:`~natsort.natsorted`
==========================

.. autofunction:: natsorted


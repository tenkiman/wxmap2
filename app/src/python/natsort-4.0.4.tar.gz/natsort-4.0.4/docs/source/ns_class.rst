.. default-domain:: py
.. currentmodule:: natsort

:class:`~natsort.ns`
====================

.. autoclass:: ns


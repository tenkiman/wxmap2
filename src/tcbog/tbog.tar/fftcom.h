c
      common/ fftcom/ trigs(1280),ifax(19)
c

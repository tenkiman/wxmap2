      common/gridg/ xlngau(imgaus),xltgau(jmgaus),yrgau(jmgp2)
     x,     dlngau,pimul

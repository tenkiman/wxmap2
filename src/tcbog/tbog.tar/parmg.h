      parameter(imgaus=480,jmgaus=imgaus/2,jvolmx=25,
     x        jmgp2=jmgaus+2)
